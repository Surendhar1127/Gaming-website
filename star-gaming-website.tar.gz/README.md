# ⭐ Star Gaming Website

A modern, visually stunning gaming channel website built with React, Vite, and Tailwind CSS.

## 🎮 Features

- **Animated Hero Section** with floating particles and glowing effects
- **Featured Games Grid** with hover animations
- **Weekly Streaming Schedule** display
- **Stats Showcase** (subscribers, tournaments, views)
- **Responsive Design** - works on all devices
- **Smooth Animations** and transitions throughout
- **Glass Morphism Effects** for modern UI
- **Social Media Integration** (YouTube, Twitch)

## 🚀 Quick Start

### Prerequisites

Make sure you have [Node.js](https://nodejs.org/) installed (version 14 or higher).

### Installation

1. **Navigate to the project folder:**
   ```bash
   cd star-gaming-website
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Start the development server:**
   ```bash
   npm run dev
   ```

4. **Open your browser:**
   The site will automatically open at `http://localhost:3000`

## 📦 Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build

## 🎨 Customization

### Change Colors
Edit the gradient colors in `src/App.jsx`:
```jsx
className="bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900"
```

### Update Games
Modify the `games` array in `src/App.jsx`:
```jsx
const games = [
  { 
    title: 'Your Game', 
    image: 'image-url',
    viewers: '1.5K',
    category: 'Genre'
  },
  // Add more games...
];
```

### Modify Schedule
Update the `schedule` array in `src/App.jsx`:
```jsx
const schedule = [
  { day: 'Monday', game: 'Game Name', time: '8:00 PM EST' },
  // Add more schedule items...
];
```

## 🛠️ Tech Stack

- **React 18** - UI library
- **Vite** - Build tool and dev server
- **Tailwind CSS** - Utility-first CSS framework
- **Lucide React** - Icon library
- **PostCSS** - CSS processing
- **Autoprefixer** - CSS vendor prefixing

## 📱 Responsive Breakpoints

- Mobile: < 768px
- Tablet: 768px - 1024px
- Desktop: > 1024px

## 🎯 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## 📝 License

This project is open source and available under the MIT License.

## 🤝 Contributing

Feel free to fork this project and make it your own!

## 💡 Tips

- Replace placeholder images with your actual gaming screenshots
- Update social media links to your channels
- Customize the color scheme to match your brand
- Add more sections as needed

## 🐛 Troubleshooting

**Port already in use?**
Edit `vite.config.js` and change the port number:
```js
server: {
  port: 3001, // Change to any available port
  open: true
}
```

**Dependencies not installing?**
Try:
```bash
npm cache clean --force
npm install
```

---

Built with ❤️ for gamers by gamers
